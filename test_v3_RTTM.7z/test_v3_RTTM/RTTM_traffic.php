<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bexel O J</title>
<style>
  .centered {
    display: flex;
    justify-content: center;
    align-items: center;
    height: calc(100vh - 40px); /* Make it full height of the viewport minus 40px */
    margin-top: 0px; /* Add space from the top */
    margin-left: 0px; /* Add space from the left */
  }
  .container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    width: 660px;
    height: 200px;
  }
  .square {
    position: relative;
    width: 100px;
    height: 100px;
    background-color: rgb(26, 65, 163);
    margin: 10px;
  }
  .led {
    position: absolute;
    width: 20px;
    height: 20px;
    background-color: black(49, 21, 189);
    cursor: pointer;
    border-radius: 20%;
    outline: 1.5px solid black; /* Add outline */
  }
  
 .top-left {
    top: 100px;
    left: 100px;
  }
  

</style>
</head>
<body>
<div class="container">
  
  <div class="square">
<?php
$servername = "localhost";
$username = "root";
$password = "MYSQLroot";
$dbname = "smarttrafficms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Fetch data from database
$sql = "SELECT DISPLAY_COLOR FROM smarttrafficms.INTERSECTIONS"; // Example query, adjust as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $display_color = $row["DISPLAY_COLOR"];

  // Determine LED color based on DISPLAY_COLOR value
  switch ($display_color) {
    case 0:
      echo '<div class="led top-left" style="background-color: #17F905;"></div>';
      break;
    case 1:
      echo '<div class="led top-left" style="background-color: #A59F0F;"></div>';
      break;
    case 2:
      echo '<div class="led top-left" style="background-color: red;"></div>';
      break;
    default:
      echo '<div class="led top-left" style="background-color: blue;"></div>'; // Default color if value is not recognized
  }
} 
else 
{
  echo '<div class="led top-left" style="background-color: black;"></div>'; // Default color if no data found
}

// Close the database connection
?>
  </div>
  
  <div class="square">
<?php
// Fetch data from database
$sql = "SELECT DISPLAY_COLOR FROM smarttrafficms.INTERSECTIONS LIMIT 1, 1"; // Example query, adjust as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $display_color = $row["DISPLAY_COLOR"];

  // Determine LED color based on DISPLAY_COLOR value
  switch ($display_color) {
    case 0:
      echo '<div class="led top-left" style="background-color: #17F905;"></div>';
      break;
    case 1:
      echo '<div class="led top-left" style="background-color: #A59F0F;"></div>';
      break;
    case 2:
      echo '<div class="led top-left" style="background-color: red;"></div>';
      break;
    default:
      echo '<div class="led top-left" style="background-color: blue;"></div>'; // Default color if value is not recognized
  }
} 
else 
{
  echo '<div class="led top-left" style="background-color: black;"></div>'; // Default color if no data found
}

// Close the database connection
//$conn->close();
?>
  </div>
  
  <div class="square">
<?php
// Fetch data from database
$sql = "SELECT DISPLAY_COLOR FROM smarttrafficms.INTERSECTIONS LIMIT 2, 1"; // Example query, adjust as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $display_color = $row["DISPLAY_COLOR"];

  // Determine LED color based on DISPLAY_COLOR value
  switch ($display_color) {
    case 0:
      echo '<div class="led top-left" style="background-color: #17F905;"></div>';
      break;
    case 1:
      echo '<div class="led top-left" style="background-color: #A59F0F;"></div>';
      break;
    case 2:
      echo '<div class="led top-left" style="background-color: red;"></div>';
      break;
    default:
      echo '<div class="led top-left" style="background-color: blue;"></div>'; // Default color if value is not recognized
  }
} 
else 
{
  echo '<div class="led top-left" style="background-color: black;"></div>'; // Default color if no data found
}

// Close the database connection
//$conn->close();
?>
  </div>
  
  <div class="square">
<?php
// Fetch data from database
$sql = "SELECT DISPLAY_COLOR FROM smarttrafficms.INTERSECTIONS LIMIT 3, 1"; // Example query, adjust as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $display_color = $row["DISPLAY_COLOR"];

  // Determine LED color based on DISPLAY_COLOR value
  switch ($display_color) {
    case 0:
      echo '<div class="led top-left" style="background-color: #17F905;"></div>';
      break;
    case 1:
      echo '<div class="led top-left" style="background-color: #A59F0F;"></div>';
      break;
    case 2:
      echo '<div class="led top-left" style="background-color: red;"></div>';
      break;
    default:
      echo '<div class="led top-left" style="background-color: blue;"></div>'; // Default color if value is not recognized
  }
} 
else 
{
  echo '<div class="led top-left" style="background-color: black;"></div>'; // Default color if no data found
}

// Close the database connection
//$conn->close();
?>
  </div>
  
  <div class="square">
  </div>
  
  <div class="square">
<?php
// Fetch data from database
$sql = "SELECT DISPLAY_COLOR FROM smarttrafficms.INTERSECTIONS LIMIT 4, 1"; // Example query, adjust as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $display_color = $row["DISPLAY_COLOR"];

  // Determine LED color based on DISPLAY_COLOR value
  switch ($display_color) {
    case 0:
      echo '<div class="led top-left" style="background-color: #17F905;"></div>';
      break;
    case 1:
      echo '<div class="led top-left" style="background-color: #A59F0F;"></div>';
      break;
    case 2:
      echo '<div class="led top-left" style="background-color: red;"></div>';
      break;
    default:
      echo '<div class="led top-left" style="background-color: blue;"></div>'; // Default color if value is not recognized
  }
} 
else 
{
  echo '<div class="led top-left" style="background-color: black;"></div>'; // Default color if no data found
}

// Close the database connection
//$conn->close();
?>
  </div>
  
  <div class="square">
<?php
// Fetch data from database
$sql = "SELECT DISPLAY_COLOR FROM smarttrafficms.INTERSECTIONS LIMIT 5, 1"; // Example query, adjust as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $display_color = $row["DISPLAY_COLOR"];

  // Determine LED color based on DISPLAY_COLOR value
  switch ($display_color) {
    case 0:
      echo '<div class="led top-left" style="background-color: #17F905;"></div>';
      break;
    case 1:
      echo '<div class="led top-left" style="background-color: #A59F0F;"></div>';
      break;
    case 2:
      echo '<div class="led top-left" style="background-color: red;"></div>';
      break;
    default:
      echo '<div class="led top-left" style="background-color: blue;"></div>'; // Default color if value is not recognized
  }
} 
else 
{
  echo '<div class="led top-left" style="background-color: black;"></div>'; // Default color if no data found
}

// Close the database connection
//$conn->close();
?>
  </div>
  
  <div class="square">
<?php
// Fetch data from database
$sql = "SELECT DISPLAY_COLOR FROM smarttrafficms.INTERSECTIONS LIMIT 6, 1"; // Example query, adjust as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $display_color = $row["DISPLAY_COLOR"];

  // Determine LED color based on DISPLAY_COLOR value
  switch ($display_color) {
    case 0:
      echo '<div class="led top-left" style="background-color: #17F905;"></div>';
      break;
    case 1:
      echo '<div class="led top-left" style="background-color: #A59F0F;"></div>';
      break;
    case 2:
      echo '<div class="led top-left" style="background-color: red;"></div>';
      break;
    default:
      echo '<div class="led top-left" style="background-color: blue;"></div>'; // Default color if value is not recognized
  }
} 
else 
{
  echo '<div class="led top-left" style="background-color: black;"></div>'; // Default color if no data found
}

// Close the database connection
//$conn->close();
?>
  </div>
  
  <div class="square">
<?php
// Fetch data from database
$sql = "SELECT DISPLAY_COLOR FROM smarttrafficms.INTERSECTIONS LIMIT 7, 1"; // Example query, adjust as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $display_color = $row["DISPLAY_COLOR"];

  // Determine LED color based on DISPLAY_COLOR value
  switch ($display_color) {
    case 0:
      echo '<div class="led top-left" style="background-color: #17F905;"></div>';
      break;
    case 1:
      echo '<div class="led top-left" style="background-color: #A59F0F;"></div>';
      break;
    case 2:
      echo '<div class="led top-left" style="background-color: red;"></div>';
      break;
    default:
      echo '<div class="led top-left" style="background-color: blue;"></div>'; // Default color if value is not recognized
  }
} 
else 
{
  echo '<div class="led top-left" style="background-color: black;"></div>'; // Default color if no data found
}

// Close the database connection
//$conn->close();
?>
  </div>
  
  <div class="square">
  </div>
  
  <div class="square">
<?php
// Fetch data from database
$sql = "SELECT DISPLAY_COLOR FROM smarttrafficms.INTERSECTIONS LIMIT 8, 1"; // Example query, adjust as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $display_color = $row["DISPLAY_COLOR"];

  // Determine LED color based on DISPLAY_COLOR value
  switch ($display_color) {
    case 0:
      echo '<div class="led top-left" style="background-color: #17F905;"></div>';
      break;
    case 1:
      echo '<div class="led top-left" style="background-color: #A59F0F;"></div>';
      break;
    case 2:
      echo '<div class="led top-left" style="background-color: red;"></div>';
      break;
    default:
      echo '<div class="led top-left" style="background-color: blue;"></div>'; // Default color if value is not recognized
  }
} 
else 
{
  echo '<div class="led top-left" style="background-color: black;"></div>'; // Default color if no data found
}

// Close the database connection
//$conn->close();
?>
  </div>
  
  <div class="square">
<?php
// Fetch data from database
$sql = "SELECT DISPLAY_COLOR FROM smarttrafficms.INTERSECTIONS LIMIT 9, 1"; // Example query, adjust as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $display_color = $row["DISPLAY_COLOR"];

  // Determine LED color based on DISPLAY_COLOR value
  switch ($display_color) {
    case 0:
      echo '<div class="led top-left" style="background-color: #17F905;"></div>';
      break;
    case 1:
      echo '<div class="led top-left" style="background-color: #A59F0F;"></div>';
      break;
    case 2:
      echo '<div class="led top-left" style="background-color: red;"></div>';
      break;
    default:
      echo '<div class="led top-left" style="background-color: blue;"></div>'; // Default color if value is not recognized
  }
} 
else 
{
  echo '<div class="led top-left" style="background-color: black;"></div>'; // Default color if no data found
}

// Close the database connection
//$conn->close();
?>
  </div>
  
  <div class="square">
<?php
// Fetch data from database
$sql = "SELECT DISPLAY_COLOR FROM smarttrafficms.INTERSECTIONS LIMIT 10, 1"; // Example query, adjust as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $display_color = $row["DISPLAY_COLOR"];

  // Determine LED color based on DISPLAY_COLOR value
  switch ($display_color) {
    case 0:
      echo '<div class="led top-left" style="background-color: #17F905;"></div>';
      break;
    case 1:
      echo '<div class="led top-left" style="background-color: #A59F0F;"></div>';
      break;
    case 2:
      echo '<div class="led top-left" style="background-color: red;"></div>';
      break;
    default:
      echo '<div class="led top-left" style="background-color: blue;"></div>'; // Default color if value is not recognized
  }
} 
else 
{
  echo '<div class="led top-left" style="background-color: black;"></div>'; // Default color if no data found
}

// Close the database connection
//$conn->close();
?>
  </div>
  
  <div class="square">
<?php
// Fetch data from database
$sql = "SELECT DISPLAY_COLOR FROM smarttrafficms.INTERSECTIONS LIMIT 11, 1"; // Example query, adjust as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $display_color = $row["DISPLAY_COLOR"];

  // Determine LED color based on DISPLAY_COLOR value
  switch ($display_color) {
    case 0:
      echo '<div class="led top-left" style="background-color: #17F905;"></div>';
      break;
    case 1:
      echo '<div class="led top-left" style="background-color: #A59F0F;"></div>';
      break;
    case 2:
      echo '<div class="led top-left" style="background-color: red;"></div>';
      break;
    default:
      echo '<div class="led top-left" style="background-color: blue;"></div>'; // Default color if value is not recognized
  }
} 
else 
{
  echo '<div class="led top-left" style="background-color: black;"></div>'; // Default color if no data found
}

// Close the database connection
//$conn->close();
?>
  </div>
  
  <div class="square">
  </div>
  
  <div class="square">
<?php
// Fetch data from database
$sql = "SELECT DISPLAY_COLOR FROM smarttrafficms.INTERSECTIONS LIMIT 12, 1"; // Example query, adjust as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $display_color = $row["DISPLAY_COLOR"];

  // Determine LED color based on DISPLAY_COLOR value
  switch ($display_color) {
    case 0:
      echo '<div class="led top-left" style="background-color: #17F905;"></div>';
      break;
    case 1:
      echo '<div class="led top-left" style="background-color: #A59F0F;"></div>';
      break;
    case 2:
      echo '<div class="led top-left" style="background-color: red;"></div>';
      break;
    default:
      echo '<div class="led top-left" style="background-color: blue;"></div>'; // Default color if value is not recognized
  }
} 
else 
{
  echo '<div class="led top-left" style="background-color: black;"></div>'; // Default color if no data found
}

// Close the database connection
//$conn->close();
?>
  </div>
  
  <div class="square">
<?php
// Fetch data from database
$sql = "SELECT DISPLAY_COLOR FROM smarttrafficms.INTERSECTIONS LIMIT 13, 1"; // Example query, adjust as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $display_color = $row["DISPLAY_COLOR"];

  // Determine LED color based on DISPLAY_COLOR value
  switch ($display_color) {
    case 0:
      echo '<div class="led top-left" style="background-color: #17F905;"></div>';
      break;
    case 1:
      echo '<div class="led top-left" style="background-color: #A59F0F;"></div>';
      break;
    case 2:
      echo '<div class="led top-left" style="background-color: red;"></div>';
      break;
    default:
      echo '<div class="led top-left" style="background-color: blue;"></div>'; // Default color if value is not recognized
  }
} 
else 
{
  echo '<div class="led top-left" style="background-color: black;"></div>'; // Default color if no data found
}

// Close the database connection
//$conn->close();
?>
  </div>
  
  <div class="square">
<?php
// Fetch data from database
$sql = "SELECT DISPLAY_COLOR FROM smarttrafficms.INTERSECTIONS LIMIT 14, 1"; // Example query, adjust as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $display_color = $row["DISPLAY_COLOR"];

  // Determine LED color based on DISPLAY_COLOR value
  switch ($display_color) {
    case 0:
      echo '<div class="led top-left" style="background-color: #17F905;"></div>';
      break;
    case 1:
      echo '<div class="led top-left" style="background-color: #A59F0F;"></div>';
      break;
    case 2:
      echo '<div class="led top-left" style="background-color: red;"></div>';
      break;
    default:
      echo '<div class="led top-left" style="background-color: blue;"></div>'; // Default color if value is not recognized
  }
} 
else 
{
  echo '<div class="led top-left" style="background-color: black;"></div>'; // Default color if no data found
}

// Close the database connection
//$conn->close();
?>
  </div>
  
  <div class="square">
<?php
// Fetch data from database
$sql = "SELECT DISPLAY_COLOR FROM smarttrafficms.INTERSECTIONS LIMIT 15, 1"; // Example query, adjust as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $display_color = $row["DISPLAY_COLOR"];

  // Determine LED color based on DISPLAY_COLOR value
  switch ($display_color) {
    case 0:
      echo '<div class="led top-left" style="background-color: #17F905;"></div>';
      break;
    case 1:
      echo '<div class="led top-left" style="background-color: #A59F0F;"></div>';
      break;
    case 2:
      echo '<div class="led top-left" style="background-color: red;"></div>';
      break;
    default:
      echo '<div class="led top-left" style="background-color: blue;"></div>'; // Default color if value is not recognized
  }
} 
else 
{
  echo '<div class="led top-left" style="background-color: black;"></div>'; // Default color if no data found
}

// Close the database connection
$conn->close();
?>
  </div>
  
  <div class="square">
  </div>
  
  <div class="square">
  </div>
  
  <div class="square">
  </div>
  
  <div class="square">
  </div>
  
  <div class="square">
  </div>
  <div class="square">
  </div>

</div>


</body>
</html>
